/*
 * File: Subsystem_types.h
 *
 * Code generated for Simulink model 'Subsystem'.
 *
 * Model version                  : 1.1049
 * Simulink Coder version         : 8.2 (R2012a) 29-Dec-2011
 * TLC version                    : 8.2 (Dec 29 2011)
 * C/C++ source code generated on : Fri Dec 07 20:58:54 2012
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Freescale->HC(S)12
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Subsystem_types_h_
#define RTW_HEADER_Subsystem_types_h_

/* Forward declaration for rtModel */
typedef struct RT_MODEL_Subsystem RT_MODEL_Subsystem;

#endif                                 /* RTW_HEADER_Subsystem_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
